import React from 'react'

export default function ViewFreeTrial() {
  return (
    <div>ViewFreeTrial</div>
  )
}
