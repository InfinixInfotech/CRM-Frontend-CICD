import React from 'react'

export default function Kyc() {
  return (
    <div>Kyc</div>
  )
}
