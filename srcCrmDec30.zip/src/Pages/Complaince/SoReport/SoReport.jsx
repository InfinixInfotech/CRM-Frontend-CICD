import React from 'react'

export default function SoReport() {
  return (
    <div>SoReport</div>
  )
}
