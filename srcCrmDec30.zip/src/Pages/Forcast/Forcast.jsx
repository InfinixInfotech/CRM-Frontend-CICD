import React from 'react'

export default function Forcast() {
  return (
    <div>Forcast</div>
  )
}
