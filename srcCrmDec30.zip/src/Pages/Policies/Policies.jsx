import React from 'react'

export default function Policies() {
  return (
    <div>Policies</div>
  )
}
