import React from 'react'
import SalesDashboard from './SalesDashboard/SalesDashboard'
export default function Dashboard() {
  return (
    <div>
        {/* <SalesDashboard/> */}
    </div>
  )
}
