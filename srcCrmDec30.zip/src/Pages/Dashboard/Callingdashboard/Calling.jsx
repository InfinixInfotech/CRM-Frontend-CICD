import React from 'react'

export default function Calling() {
  return (
    <div><center>Calling</center></div>
  )
}
