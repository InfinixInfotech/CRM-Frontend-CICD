import React from 'react'
import' /FollowUp.css' 

export default function FollowUp() {
  return (
    <div className='heading'>FollowUp</div>
  )
}
