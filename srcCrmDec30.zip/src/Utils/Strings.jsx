import React from 'react'

export default function Strings() {
  return (
    <div>Strings</div>
  )
}
